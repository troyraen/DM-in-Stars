$MESA_DIR = '/Users/bpaxton/mesa'
